package com.aliyun.odps.mapred;

public enum LocalTaskStatus {
	PREPARED, WAITNG, RUNNING, SUCCEEDED, FAILED, KILLED;
}
