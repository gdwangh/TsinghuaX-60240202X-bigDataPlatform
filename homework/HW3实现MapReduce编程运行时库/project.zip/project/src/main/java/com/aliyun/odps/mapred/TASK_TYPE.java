package com.aliyun.odps.mapred;

public enum TASK_TYPE {
	TASK_TYPE_MAP, TASK_TYPE_SORT, TASK_TYPE_REDUCE;
}
