package edu.tsinghua.bigdata;

public interface RecordReader {
}
