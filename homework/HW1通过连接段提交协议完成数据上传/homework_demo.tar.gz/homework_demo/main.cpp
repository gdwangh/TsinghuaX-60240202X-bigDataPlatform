#include "test.h"
using namespace homework;

int main()
{
    Test::TestUploadNegetive();
    return 0;
}
