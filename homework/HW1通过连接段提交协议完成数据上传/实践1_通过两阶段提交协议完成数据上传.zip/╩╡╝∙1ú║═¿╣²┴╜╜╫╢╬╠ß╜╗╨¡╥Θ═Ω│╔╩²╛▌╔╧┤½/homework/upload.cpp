#include "server.h"

using namespace std;
using namespace homework;

bool Server::UpdateTable(const string& tableName, const string& content)
{
}

bool Worker::UpdateTable(const string& tableName, const string& content)
{
}
